Flutter - Read me

To run the Flutter examples, please follow the below steps.
 
* Click 'Explore Demo Source' button in Syncfusion control panel under Flutter menu.
* Navigate to the 'SampleBrowser' folder and open it using VS code or Android studio.
* Now get the required packages referred in the 'pubspec.yaml' file to run the project.
* Run the project by connecting an emulator or a physical device.
 
Note - Android SDK 16 or later version is required to run the flutter examples.