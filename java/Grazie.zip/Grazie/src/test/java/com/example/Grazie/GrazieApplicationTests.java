package com.example.Grazie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrazieApplicationTests {

	@Test
	void contextLoads() {
	}

}
