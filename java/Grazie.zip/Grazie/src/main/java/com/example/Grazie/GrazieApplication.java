package com.example.Grazie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrazieApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrazieApplication.class, args);
	}

}
